var annotated_dup =
[
    [ "GLBody", "class_g_l_body.html", "class_g_l_body" ],
    [ "GLBodyGroup", "class_g_l_body_group.html", "class_g_l_body_group" ],
    [ "GLColorRgba", "class_g_l_color_rgba.html", "class_g_l_color_rgba" ],
    [ "GLDisc", "class_g_l_disc.html", "class_g_l_disc" ],
    [ "GLESRenderer", "class_g_l_e_s_renderer.html", "class_g_l_e_s_renderer" ],
    [ "GLField", "class_g_l_field.html", "class_g_l_field" ],
    [ "GLItem", "class_g_l_item.html", "class_g_l_item" ],
    [ "GLMouseRay", "class_g_l_mouse_ray.html", "class_g_l_mouse_ray" ],
    [ "GLMultipleBody", "class_g_l_multiple_body.html", "class_g_l_multiple_body" ],
    [ "GLPoint", "class_g_l_point.html", "class_g_l_point" ],
    [ "main", "classmain.html", null ],
    [ "music", "classmusic.html", "classmusic" ],
    [ "MyGLItem", "class_my_g_l_item.html", "class_my_g_l_item" ],
    [ "ShaderDebugger", "class_shader_debugger.html", "class_shader_debugger" ]
];