var dir_f41a1010824ab2636a766be234fb9e42 =
[
    [ "QT Projects", "dir_77865d38fea6b5a94cf892f5035adb04.html", "dir_77865d38fea6b5a94cf892f5035adb04" ]
];