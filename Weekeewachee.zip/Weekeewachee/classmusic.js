var classmusic =
[
    [ "music", "classmusic.html#aeb16d9f22b7eb36ce892a9b8874e9a91", null ],
    [ "isEnabled", "classmusic.html#adc1edc82df07e609d0b66b1017718e0d", null ],
    [ "playSound", "classmusic.html#aea14df2ae81e5671f550c15ad7cf4aba", null ],
    [ "setEnabled", "classmusic.html#a2c1769ba9772bf12611a013a8f6ee734", null ]
];