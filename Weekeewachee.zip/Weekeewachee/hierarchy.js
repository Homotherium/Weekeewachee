var hierarchy =
[
    [ "GLPoint", "class_g_l_point.html", null ],
    [ "main", "classmain.html", null ],
    [ "QObject", null, [
      [ "GLESRenderer", "class_g_l_e_s_renderer.html", null ],
      [ "music", "classmusic.html", null ]
    ] ],
    [ "QOpenGLFunctions", null, [
      [ "GLBody", "class_g_l_body.html", [
        [ "GLBodyGroup", "class_g_l_body_group.html", null ],
        [ "GLDisc", "class_g_l_disc.html", null ],
        [ "GLField", "class_g_l_field.html", null ],
        [ "GLMouseRay", "class_g_l_mouse_ray.html", null ],
        [ "GLMultipleBody", "class_g_l_multiple_body.html", null ]
      ] ],
      [ "GLESRenderer", "class_g_l_e_s_renderer.html", null ]
    ] ],
    [ "QQuickItem", null, [
      [ "GLItem", "class_g_l_item.html", [
        [ "MyGLItem", "class_my_g_l_item.html", null ]
      ] ]
    ] ],
    [ "QVector4D", null, [
      [ "GLColorRgba", "class_g_l_color_rgba.html", null ]
    ] ],
    [ "ShaderDebugger", "class_shader_debugger.html", null ]
];