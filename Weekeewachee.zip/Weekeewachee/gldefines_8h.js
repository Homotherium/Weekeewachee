var gldefines_8h =
[
    [ "IndexType", "gldefines_8h.html#af3c748960f29c42e5b7f1dc449ab66ff", null ],
    [ "M_PIf", "gldefines_8h.html#acbb42dc053fedc161079f0a4d20a64e8", null ],
    [ "USE_QOPENGL_FUNCTIONS", "gldefines_8h.html#a4bb3820ed59b542e07eefaf6b9df5a02", null ]
];